//
//  LookPassController.h
//  DJRegisterViewDemo
//
//  Created by asios on 15/8/15.
//  Copyright (c) 2015年 梁大红. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LookPassController : UIViewController

@end
