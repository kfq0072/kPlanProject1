//
//  AppDelegate.m
//  ASDemo
//
//  Created by asios on 15/8/15.
//  Copyright (c) 2015年 梁大红. All rights reserved.
//

#import "AppDelegate.h"
#import "RootController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate



- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:[[RootController alloc] init]];
    nc.navigationBar.translucent = NO;
    
    self.window.rootViewController = nc;
    self.window.backgroundColor = [UIColor whiteColor];
    return YES;
}



@end
