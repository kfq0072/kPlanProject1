# JxbLovelyLogin
一个可爱的登陆界面，动画效果仿自国外网站readme.io


![](https://raw.githubusercontent.com/JxbSir/JxbLovelyLogin/master/screenshot.gif)
