//
//  Comment.m
//  JHCellConfigDemo
//
//  Created by JC_Hu on 15/3/20.
//  Copyright (c) 2015年 JCHu. All rights reserved.
//

#import "Comment.h"

@implementation Comment

@end
