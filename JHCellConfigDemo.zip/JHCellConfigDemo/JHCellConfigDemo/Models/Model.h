//
//  Model.h
//  JHCellConfigDemo
//
//  Created by JC_Hu on 15/3/9.
//  Copyright (c) 2015年 JCHu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

@property (nonatomic, strong) NSString *imageName1;

@property (nonatomic, strong) NSString *imageName2;

@property (nonatomic, strong) NSString *imageName3;

@property (nonatomic, strong) NSString *imageName4;


@end
