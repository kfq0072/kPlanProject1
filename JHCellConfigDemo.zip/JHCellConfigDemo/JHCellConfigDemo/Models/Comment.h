//
//  Comment.h
//  JHCellConfigDemo
//
//  Created by JC_Hu on 15/3/20.
//  Copyright (c) 2015年 JCHu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Comment : NSObject

@property (nonatomic, strong) NSString *userName;

@property (nonatomic, strong) NSString *content;


@end
