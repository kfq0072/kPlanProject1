//
//  Macro.h
//  JHCellConfigDemo
//
//  Created by JC_Hu on 15/3/9.
//  Copyright (c) 2015年 JCHu. All rights reserved.
//

#ifndef JHCellConfigDemo_Macro_h
#define JHCellConfigDemo_Macro_h


#endif

#define kWidthOfScreen [UIScreen mainScreen].bounds.size.width