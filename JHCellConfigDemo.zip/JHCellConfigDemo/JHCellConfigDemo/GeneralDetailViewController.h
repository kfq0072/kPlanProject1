//
//  GeneralDetailViewController.h
//  JHCellConfigDemo
//
//  Created by JC_Hu on 15/3/17.
//  Copyright (c) 2015年 JCHu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GeneralDetailViewController : UIViewController


@end
